﻿using System;

namespace PetCare.IoC
{
    public class Class1
    {
    }
}
