﻿using PetCare.Domain.Dto;
using PetCare.Domain.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace PetCare.Domain.Service.Abstraction
{
    public interface IVeterinarioService
    {
        void CadastrarVeterinario(Veterinario veterinario);

        Veterinario ObterVeterinarioPorId(int id);

        IList<Veterinario> ListaVeterinario();

        IList<AgendaDisponivelDTO> ListarVeterinarioDisponivel();
    }
}
