﻿using PetCare.Domain.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace PetCare.Domain.Service.Abstraction
{
    public interface IAnimalService
    {
        void CadastrarAnimal(int idCliente, Animal animal);

        void AlterarAnimal(Animal animal);

        IList<Animal>ListaAnimal(int IdCliente);

        Animal ObterAnimalPorId(int IdAnimal);
    }
}
