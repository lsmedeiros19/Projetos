﻿using PetCare.Domain.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace PetCare.Domain.Service.Abstraction
{
    public interface IAgendamentoService
    {
        void CadastrarAgendamento(Agendamento agendamento);

        IList<Agendamento> ListarAgendamentoDoDia();
        

    }
}
