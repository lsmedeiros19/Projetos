﻿using PetCare.Domain.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace PetCare.Domain.Service.Abstraction
{
    public interface IAtendimentoService
    {
        void CadastrarAtendimento(Atendimento atendimento);

        Atendimento ObterAtendimentoPorId(int id);
    }
}
