﻿using PetCare.Domain.Models;
using System;

namespace PetCare.Repository
{
    public class ClienteRepository
    {
        public void CadastrarCliente(Cliente cliente)
        {
           
        }

        public void ObterClientePorCpf(string cpf)
        {
            
        }
    }
}
