﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PetCare.Domain.Enums
{
    public enum eTipoAnimal : int
    {
        Cachorro = 1,
        Gato     = 2,
        Hamster  = 3
    }
}
