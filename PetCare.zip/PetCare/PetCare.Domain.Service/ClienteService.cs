﻿using PetCare.Domain.Models;
using PetCare.Domain.Service.Abstraction;
using System;
using System.Collections.Generic;
using System.Text;

namespace PetCare.Domain.Service
{
    public class ClienteService : IClienteService
    {
        public ClienteService()
        {
            //Chamar Interface do repository
        }

        public void CadastrarCliente(Cliente cliente)
        {
            if (cliente != null)
            {
                //Chamar o repository
            }
            
        }

        public Cliente ObterClientePorCpf(string cpf)
        {
            Cliente cliente = new Cliente();
            if(cpf != "")
            {

            }
            return cliente;
        }

    }
}
