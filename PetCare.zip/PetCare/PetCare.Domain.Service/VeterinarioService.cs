﻿using PetCare.Domain.Dto;
using PetCare.Domain.Models;
using PetCare.Domain.Service.Abstraction;
using System;
using System.Collections.Generic;
using System.Text;

namespace PetCare.Domain.Service
{
    public class VeterinarioService : IVeterinarioService
    {
        public void CadastrarVeterinario(Veterinario veterinario)
        {
            throw new NotImplementedException();
        }

        public IList<AgendaDisponivelDTO> ListarVeterinarioDisponivel()
        {
            throw new NotImplementedException();
        }

        public IList<Veterinario> ListaVeterinario()
        {
            throw new NotImplementedException();
        }

        public Veterinario ObterVeterinarioPorId(int id)
        {
            throw new NotImplementedException();
        }
    }
}
