﻿using PetCare.Domain.Models;
using PetCare.Domain.Service.Abstraction;
using System;
using System.Collections.Generic;
using System.Text;

namespace PetCare.Domain.Service
{
    public class AgendamentoService : IAgendamentoService
    {
        public void CadastrarAgendamento(Agendamento agendamento)
        {
            throw new NotImplementedException();
        }

        public IList<Agendamento> ListarAgendamentoDoDia()
        {
            throw new NotImplementedException();
        }
    }
}
