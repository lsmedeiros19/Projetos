﻿using PetCare.Domain.Models;
using PetCare.Domain.Service.Abstraction;
using System;
using System.Collections.Generic;
using System.Text;

namespace PetCare.Domain.Service
{
    public class AnimalService : IAnimalService
    {
        public void AlterarAnimal(Animal animal)
        {
            throw new NotImplementedException();
        }

        public void CadastrarAnimal(int idCliente, Animal animal)
        {
            throw new NotImplementedException();
        }

        public IList<Animal> ListaAnimal(int IdCliente)
        {
            throw new NotImplementedException();
        }

        public Animal ObterAnimalPorId(int IdAnimal)
        {
            throw new NotImplementedException();
        }
    }
}
