﻿using System;

namespace Repositorio
{
    public class Class1
    {
    }
}
