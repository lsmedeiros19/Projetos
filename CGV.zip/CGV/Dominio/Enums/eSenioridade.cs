﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Dominio.Enums
{
    public enum eSenioridade : int
    {
        Junior = 1,
        Pleno = 2,
        Senior = 3
    }
}
