﻿using Dominio.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace Dominio.Advogado
{
    public class Advogado
    {
        /// <summary>
        /// Id do Advogado
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Nome do Advogado
        /// </summary>
        public string Nome { get; set; }

        /// <summary>
        /// Senioridade
        /// </summary>
        public eSenioridade Tipo { get; set; }

        /// <summary>
        /// Endereço do Advogado
        /// </summary>
        public string Endereco { get; set; }
    }
}
